package Main;

import Utilities.DBConnection;
import com.twilio.Twilio;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.SQLException;


import static Utilities.SmsApp.sms;
import static View_Controller.LoginController.mainTitle;

public class Main extends Application {

    public static final String ACCOUNT_SID = "ACf1f7fb986c7e97306227017777fab45e";
    public static final String AUTH_TOKEN = "de37a76976f192dcbb981097fbbe16b9";
    @Override
    public void start(Stage primaryStage) throws Exception {
        URL url = getClass().getResource("/view/login.fxml");
        Parent root = FXMLLoader.load(url);
        primaryStage.setTitle(mainTitle);
        primaryStage.setScene(new Scene(root, 261, 232));
        primaryStage.show();
        root.requestFocus();
    }

    public static void main(String[] args) throws SQLException, Exception {
        Twilio.init(
                ACCOUNT_SID, AUTH_TOKEN);
        sms();
        launch(args);
        DBConnection.closeConnection();

    }
}


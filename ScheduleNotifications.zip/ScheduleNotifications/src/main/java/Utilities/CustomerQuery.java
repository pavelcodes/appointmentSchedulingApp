package Utilities;


import Model.Customer;
import Model.User;
import java.sql.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.time.Instant;

import static Model.Customer.customers;
import static Model.User.users;
import static View_Controller.LoginController.currentUser;
import static java.sql.Statement.RETURN_GENERATED_KEYS;

public class CustomerQuery {
    //customer View String
    public static final String customerView = "CREATE OR REPLACE VIEW CustomerView AS SELECT c.customerId, c.customerName, a.address, a.address2, a.phone, a.postalCode, a.addressId, ci.cityId, ci.city, co.countryId, co.country from customer c INNER JOIN address a ON c.addressId = a.addressId INNER JOIN city ci ON a.cityId = ci.cityId INNER JOIN country co ON ci.countryId = co.countryId";
    static int oldCountryId;

    //creates view for customers
    public static void createCustomerView() throws SQLException {
        try (PreparedStatement statement = (PreparedStatement) DBConnection.connection.prepareStatement(customerView)) {
            statement.execute();
        }

    }

    public static ObservableList<Customer> getAllCustomers() throws SQLException {
        String query13 = "select customerId,customerName,address,address2,phone,addressId,postalCode,cityId,city,countryId,country from CustomerView";
        try (PreparedStatement statement = (PreparedStatement) DBConnection.connection.prepareStatement(query13)) {
            createCustomerView();
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    Customer customer = new Customer();
                    customer.setCustomerId(rs.getInt("customerId"));
                    customer.setCustomerName(rs.getString("customerName"));
                    customer.setAddressId(rs.getInt("addressId"));
                    customer.setAddress(rs.getString("address"));
                    customer.setAddress2(rs.getString("address2"));
                    customer.setPhone(rs.getString("phone"));
                    customer.setPostalCode(rs.getString("postalCode"));
                    customer.setCityId(rs.getInt("cityId"));
                    customer.setCity(rs.getString("city"));
                    customer.setCountryId(rs.getInt("countryId"));
                    customer.setCountry(rs.getString("country"));
                    customers.add(customer);
                }
                return customers;
            }
        }
    }

    public static ObservableList<User> getAllUsers() throws SQLException {
        String query7 = "select * from user";
        try (PreparedStatement statement = (PreparedStatement) DBConnection.connection.prepareStatement(query7);
             ResultSet rs = statement.executeQuery()) {
            while (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("userId"));
                user.setUsername(rs.getString("userName"));
                user.setPassword(rs.getString("password"));
                users.add(user);
            }
            return users;
        }
    }

    public static ObservableList<String> consultantList() throws SQLException {
        ObservableList<String> consultantList = FXCollections.observableArrayList();
        String query8 = "select * from user";
        try (PreparedStatement statement = (PreparedStatement) DBConnection.connection.prepareStatement(query8);
             ResultSet rs = statement.executeQuery()) {
            while (rs.next()) {
                String consultantName = rs.getString("userName");
                consultantList.add(consultantName);
            }
            return consultantList;
        }
    }


    public static Customer addCountry(Customer customer) throws SQLException {
        oldCountryId = customer.getCountryId();
        String query9 = "Select * from country where country=?";
        String query10 = "INSERT INTO country (country, createDate,createdBy,lastUpdate,lastUpdateBy) VALUES(?,?,?,?,?)";
        try (PreparedStatement statement = (PreparedStatement) DBConnection.connection.prepareStatement(query9, RETURN_GENERATED_KEYS);
             PreparedStatement statement2 = (PreparedStatement) DBConnection.connection.prepareStatement(query10, RETURN_GENERATED_KEYS)) {
            statement.setString(1, customer.getCountry());
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    int countryId = rs.getInt("countryId");
                    customer.setCountryId(countryId);
                    return customer;
                } else {
                    statement2.setString(1, customer.getCountry());
                    statement2.setTimestamp(2, Timestamp.from(Instant.now()));
                    statement2.setString(3, currentUser);
                    statement2.setTimestamp(4, Timestamp.from(Instant.now()));
                    statement2.setString(5, currentUser);
                    statement2.executeUpdate();
                    addCountry(customer);

                }
                return customer;
            }
        }

    }


    public static Customer addCity(Customer customer) throws SQLException {
        String query11 = "Select * from city where city=? AND countryId=?";
        String query12 = "INSERT INTO city (city,countryId,createDate,createdBy,lastUpdate,lastUpdateBy) VALUES(?,?,?,?,?,?)";
        try (PreparedStatement statement = (PreparedStatement) DBConnection.connection.prepareStatement(query11, RETURN_GENERATED_KEYS);
             PreparedStatement statement2 = (PreparedStatement) DBConnection.connection.prepareStatement(query12, RETURN_GENERATED_KEYS)) {
            statement.setString(1, customer.getCity());
            statement.setString(2, Integer.toString(customer.getCountryId()));

            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    int cityId = rs.getInt(1);
                    customer.setCityId(cityId);
                    return customer;
                } else {
                    statement2.setString(1, customer.getCity());
                    statement2.setInt(2, customer.getCountryId());
                    statement2.setTimestamp(3, Timestamp.from(Instant.now()));
                    statement2.setString(4, currentUser);
                    statement2.setTimestamp(5, Timestamp.from(Instant.now()));
                    statement2.setString(6, currentUser);
                    statement2.executeUpdate();
                    addCity(customer);

                }
                return customer;
            }
        }

    }

    public static Customer addAddress(Customer customer) throws SQLException {
        String query15 = "SELECT* FROM address WHERE address=? AND address2=? AND postalCode=? AND cityId=?";
        String query16 = "INSERT INTO address (address, address2, cityId, postalCode, phone, createDate, createdBy, lastUpdateBy)"
                + "VALUES (?,?,?,?,?,?,?,?)";
        try (PreparedStatement statement = (PreparedStatement) DBConnection.connection.prepareStatement(query15, RETURN_GENERATED_KEYS);
             PreparedStatement statement2 = (PreparedStatement) DBConnection.connection.prepareStatement(query16, RETURN_GENERATED_KEYS)) {
            statement.setString(1, customer.getAddress());
            statement.setString(2, customer.getAddress2());
            statement.setString(3, customer.getPostalCode());
            statement.setString(4, Integer.toString(customer.getCityId()));
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    int addressId = rs.getInt(1);
                    customer.setAddressId(addressId);
                    return customer;
                } else {
                    statement2.setString(1, customer.getAddress());
                    statement2.setString(2, customer.getAddress2());
                    statement2.setInt(3, customer.getCityId());
                    statement2.setString(4, customer.getPostalCode());
                    statement2.setString(5, customer.getPhone());
                    statement2.setTimestamp(6, Timestamp.from(Instant.now()));
                    statement2.setString(7, currentUser);
                    statement2.setString(8, currentUser);
                    statement2.executeUpdate();
                    addAddress(customer);

                }
                return customer;
            }
        }

    }

    public static void addCustomer(Customer customer) throws SQLException {
        String query17 = "UPDATE country SET country=?, createDate=?, createdBy=?, lastUpdate=?, lastUpdateBy=? WHERE countryId=?";
        String query18 = "UPDATE city SET city=?, countryId=?, createDate=?, createdBy=?, lastUpdate=?, lastUpdateBy=? WHERE cityId=? AND countryId=?";
        String query19 = "UPDATE address SET address=?, address2=?, cityId=?, postalCode=?,phone=?, createDate=?, createdBy=?, lastUpdate=?, lastUpdateBy=? WHERE addressId=?";
        String query20 = "UPDATE customer SET customerName=?, addressId=?, lastUpdate=?, lastUpdateBy=? WHERE customerId=?";
        String query21 = "INSERT INTO customer (customerName, addressId, active, createDate, createdBy, lastUpdate, lastUpdateBy) VALUES (?,?,?,?,?,?,?)";
        try (PreparedStatement statement1 = (PreparedStatement) DBConnection.connection.prepareStatement(query17);
             PreparedStatement statement2 = (PreparedStatement) DBConnection.connection.prepareStatement(query18);
             PreparedStatement statement3 = (PreparedStatement) DBConnection.connection.prepareStatement(query19);
             PreparedStatement statement4 = (PreparedStatement) DBConnection.connection.prepareStatement(query20);
             PreparedStatement statement5 = (PreparedStatement) DBConnection.connection.prepareStatement(query21)) {
            if (customer.getCustomerId() > 0) {
                addCountry(customer);
                addCity(customer);
                addAddress(customer);

                statement1.setString(1, customer.getCountry());
                statement1.setTimestamp(2, Timestamp.from(Instant.now()));
                statement1.setString(3, currentUser);
                statement1.setTimestamp(4, Timestamp.from(Instant.now()));
                statement1.setString(5, currentUser);
                statement1.setInt(6, customer.getCountryId());
                statement1.executeUpdate();

                statement2.setString(1, customer.getCity());
                statement2.setInt(2, customer.getCountryId());
                statement2.setTimestamp(3, Timestamp.from(Instant.now()));
                statement2.setString(4, currentUser);
                statement2.setTimestamp(5, Timestamp.from(Instant.now()));
                statement2.setString(6, currentUser);
                statement2.setInt(7, customer.getCityId());
                statement2.setInt(8, oldCountryId);
                statement2.executeUpdate();


                statement3.setString(1, customer.getAddress());
                statement3.setString(2, customer.getAddress2());
                statement3.setInt(3, customer.getCityId());
                statement3.setString(4, customer.getPostalCode());
                statement3.setString(5, customer.getPhone());
                statement3.setTimestamp(6, Timestamp.from(Instant.now()));
                statement3.setString(7, currentUser);
                statement3.setTimestamp(8, Timestamp.from(Instant.now()));
                statement3.setString(9, currentUser);
                statement3.setInt(10, customer.getAddressId());
                statement3.executeUpdate();


                statement4.setString(1, customer.getCustomerName());
                statement4.setInt(2, customer.getAddressId());
                statement4.setTimestamp(3, Timestamp.from(Instant.now()));
                statement4.setString(4, currentUser);
                statement4.setInt(5, customer.getCustomerId());
                statement4.executeUpdate();


            } else {
                addCountry(customer);
                addCity(customer);
                addAddress(customer);
                statement5.setString(1, customer.getCustomerName());
                statement5.setInt(2, customer.getAddressId());
                statement5.setInt(3, 1);
                statement5.setTimestamp(4, Timestamp.from(Instant.now())
                );
                statement5.setString(5, currentUser);
                statement5.setTimestamp(6, Timestamp.from(Instant.now())
                );
                statement5.setString(7, currentUser);
                statement5.executeUpdate();
            }
        }
    }

    public static ObservableList<String> customerList() throws SQLException {
        ObservableList<String> custNameList = FXCollections.observableArrayList();
        String query22 = "select * from customer";
        try (PreparedStatement statement = (PreparedStatement) DBConnection.connection.prepareStatement(query22);
             ResultSet rs = statement.executeQuery()) {
            while (rs.next()) {
                String customerName = rs.getString("customerName");
                custNameList.add(customerName);
            }
            return custNameList;
        }
    }


    public static void deleteCustomer(Customer customer) throws SQLException {
        String query23 = "DELETE customer.* FROM customer WHERE customer.customerId = ?";
        try (PreparedStatement statement = (PreparedStatement) DBConnection.connection.prepareStatement(query23)) {
            statement.setInt(1, customer.getCustomerId());
            statement.execute();
        }
    }

}


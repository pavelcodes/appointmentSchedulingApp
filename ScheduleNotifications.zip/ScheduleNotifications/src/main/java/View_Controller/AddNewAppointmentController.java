package View_Controller;


import Model.Appointment;
import Model.BusinessHours;
import Utilities.AppointmentQuery;
import Utilities.CustomerQuery;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

public class AddNewAppointmentController implements Initializable {

        @FXML
        private AnchorPane searchCustomersField;

        @FXML
        private HBox root;

        @FXML
        private Text topBannerCustomers;

        @FXML
        private Button saveNewAppointment;

        @FXML
        private Button back;

        @FXML
        private Label customerNameLabel;

        @FXML
        private Label consultantNameLabel;

        @FXML
        private Label startDateLabel;

        @FXML
        private Label startTimeLabel;

        @FXML
        private Label endDateLabel;

        @FXML
        private Label endTimeLabel;

        @FXML
        private Label appointmentTypeLabel;

        @FXML
        private ComboBox<String> customerNameCombo;

        @FXML
        private ComboBox<String> consultantCombo;

        @FXML
        private DatePicker startDateDP;

        @FXML
        private ComboBox<String> startTimeCombo;

        @FXML
        private DatePicker endDateDP;

        @FXML
        private ComboBox<String> endTimeCombo;

        @FXML
        private ComboBox<String> appointmentTypeCombo;

        @FXML
        private TextArea notesText;

        @FXML
        private Label notesLabel;
        @FXML
        private Label openLabel;

        @FXML
        private CheckBox reminderCheckbox;
        @FXML
        private Label closeLabel;

        String businessHoursClose;
        String businessHoursOpen;



        public void sendSMS() throws Exception {



                Message message = Message.creator(new PhoneNumber("+14322700487"),
                        new PhoneNumber("+13092333586"),
                        "Hello "  + "Please confirm your appointment for " ).create();

                System.out.println(message.getSid());
                return;
        }

        public static void getBusinessHours() {

                ZoneId zoneId = ZoneId.systemDefault(); //systems zoneID
                LocalDate today = LocalDate.now(zoneId); //date on system with zoneID
                LocalTime openlt = LocalTime.of( 9 , 0 ); //time of 9:00 hours
                LocalTime closelt= LocalTime.of(17,0); //sets time to 17:00 hours
                ZonedDateTime zdtOpen = ZonedDateTime.of( today , openlt , ZoneId.of("UTC")); // zdt with systems current date, open hours at 9:00 in UTC
                ZonedDateTime zdtClose = ZonedDateTime.of( today , closelt , ZoneId.of("UTC")); // zdt with systems current date, close hours at 17:00 in UTC
                DateTimeFormatter formatToCurrent = DateTimeFormatter.ofPattern("HH:mm").withZone(zoneId); // formats the Date/time to HH:mm with systemZoneID
                String openTime= formatToCurrent.format(zdtOpen); // converts today's date with 9:00 UTC to local time zone
                String closeTime= formatToCurrent.format(zdtClose); // converts today's date with 17:00 UTC to local time zone
                BusinessHours.closeTime=closeTime;
                BusinessHours.openTime=openTime;
        }


        @FXML
        void onActionBack(ActionEvent event) throws IOException {
                URL url = getClass().getResource("/view/appointmentDashboard.fxml");
                Parent root = FXMLLoader.load(url);
                Scene mainScene = new Scene(root);
                Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                app_stage.setScene(mainScene);
                app_stage.setTitle("Scheduling Application");
                app_stage.show();
        }

        @FXML
        void onActionSaveNewAppointment(ActionEvent event) throws IOException, SQLException {

                String selectedCustomerName = customerNameCombo.getSelectionModel().getSelectedItem();
                String selectedProviderName = consultantCombo.getSelectionModel().getSelectedItem();
                String selectedAppointmentType = appointmentTypeCombo.getSelectionModel().getSelectedItem();
                String notes = notesText.getText();
                LocalDate selectedStartDate = startDateDP.getValue();
                LocalDate selectedEndDate = endDateDP.getValue();


                boolean checkFields = consultantCombo.getSelectionModel().isEmpty() || customerNameCombo.getSelectionModel().isEmpty() || startTimeCombo.getSelectionModel().isEmpty() || endTimeCombo.getSelectionModel().isEmpty() || appointmentTypeCombo.getSelectionModel().isEmpty() || startDateDP.getValue() == null || endDateDP.getValue() == null;
                if (checkFields) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Error");
                        alert.setHeaderText("All Fields must be filled");
                        alert.showAndWait();
                        return;
                } else {
                        LocalTime selectedStartTime = LocalTime.parse((startTimeCombo.getSelectionModel().getSelectedItem()));
                        LocalTime selectedEndTime = LocalTime.parse((endTimeCombo.getSelectionModel().getSelectedItem()));
                        LocalTime bhOpen = LocalTime.parse(businessHoursOpen);
                        LocalTime bhClose = LocalTime.parse(businessHoursClose);
                        boolean t = selectedStartTime.isBefore(bhOpen) || selectedStartTime.isAfter(bhClose)|| selectedEndTime.isAfter(bhClose) || selectedEndTime.isBefore(bhOpen);
                        boolean d = selectedEndDate.isBefore(selectedStartDate) || selectedStartDate.isAfter(selectedEndDate);
                        boolean sameTime= selectedStartTime.equals(selectedEndTime) && selectedEndDate.equals(selectedStartDate);
                        ZoneId zoneId = ZoneId.systemDefault();//local timezone
                        DateTimeFormatter formatterUTC = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").withZone(ZoneId.of("UTC")); //fortmat to UTC

                        ZonedDateTime startZDT = ZonedDateTime.of(selectedStartDate, selectedStartTime, zoneId);
                        ZonedDateTime endZDT = ZonedDateTime.of(selectedEndDate, selectedEndTime, zoneId);

                        String startOverlap = formatterUTC.format(startZDT);
                        String endOverlap = formatterUTC.format(endZDT);

                         if (t) {
                                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                alert.setTitle("Error");
                                alert.setHeaderText("Appointment is made outside of business hours.\nThe business hours in your local time are between: " + businessHoursOpen + "\n"+ "and " + businessHoursClose);
                                alert.showAndWait();
                                return;
                        }
                        if (sameTime) {
                                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                alert.setTitle("Error");
                                alert.setHeaderText("Appointment must be at least 15 minutes long");
                                alert.showAndWait();
                                return;
                        }
                        if (d) {
                                 Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                 alert.setTitle("Error");
                                 alert.setHeaderText("The appointment cannot have an end date before start date.");
                                 alert.showAndWait();
                                 return;
                         }

                         if (AppointmentQuery.appointmentOverlap(startOverlap, endOverlap, selectedProviderName)) {
                                        return;
                                } else {
                                 String date = formatterUTC.format(startZDT);
                                        Appointment appointment = new Appointment();
                                        appointment.setCustomerName(selectedCustomerName);
                                        appointment.setConsultantName(selectedProviderName);
                                        appointment.setStartFull(formatterUTC.format(startZDT));
                                        appointment.setEndFull(formatterUTC.format(endZDT));
                                        appointment.setAppointmentType(selectedAppointmentType);
                                        appointment.setNotes(notes);
                                        AppointmentQuery.addAppointment(appointment);

                                        Message message = Message.creator(new PhoneNumber("+14322700487"),
                                         new PhoneNumber("+13092333586"),
                                         "Hello " + selectedCustomerName + "This is a reminder that you have an appointment on:  " + date + "Please respond with a \"1\" to confirm. Or 2 to cancel").create();

                                        System.out.println(message.getSid());






                                        URL url = getClass().getResource("/view/appointmentDashboard.fxml");
                                        Parent root = FXMLLoader.load(url);
                                        Scene mainScene = new Scene(root);
                                        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                                        app_stage.setScene(mainScene);
                                        app_stage.setTitle("Scheduling Application");
                                        app_stage.show();

                                }
                        }
                }

        @Override
        public void initialize(URL location, ResourceBundle resources) {
                getBusinessHours();
                businessHoursClose = BusinessHours.getCloseTime();
                businessHoursOpen = BusinessHours.getOpenTime();
                openLabel.setText(BusinessHours.openTime);
                closeLabel.setText(BusinessHours.closeTime);

                ObservableList<String> customerNameList= null;
                try {
                        customerNameList = CustomerQuery.customerList();
                } catch (SQLException e) {
                        e.printStackTrace();
                }
                customerNameCombo.setItems(customerNameList);
                ObservableList<String> consultantNameList= null;
                try {
                        consultantNameList = CustomerQuery.consultantList();
                } catch (SQLException e) {
                        e.printStackTrace();
                }
                consultantCombo.setItems(consultantNameList);
                //sets appointment type combo box
                appointmentTypeCombo.setItems(Appointment.appointmentTypes);

                startTimeCombo.setItems(Appointment.appointmentTimes);
                endTimeCombo.setItems(Appointment.appointmentTimes);
        }
}
